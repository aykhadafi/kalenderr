# Membuat APK Android (Capacitor)

Project ini sudah disiapkan untuk dibungkus menjadi aplikasi Android dengan [Capacitor](https://capacitorjs.com).
Ada dua jalur. Pilih salah satu.

| | Jalur A: GitHub Actions | Jalur B: Android Studio |
|---|---|---|
| Perlu install di komputer | Tidak ada (cukup akun GitHub) | Node.js + Android Studio (± 5 GB) |
| Waktu build | ± 5–8 menit di server GitHub | ± 3–10 menit (build pertama lebih lama) |
| Cocok untuk | Laptop biasa, cepat jadi | Mau mengatur detail aplikasi, APK rilis |

---

## Langkah 0 (wajib, kedua jalur): isi URL Apps Script

Buka `index.html`, cari `window.KK_CONFIG`, isi `scriptUrl` (URL `/exec`) atau `deploymentId`.
URL ini ikut tertanam di aplikasi. Jika nanti URL berubah, APK harus dibuat ulang.

---

## Jalur A: build otomatis di GitHub (tanpa Android Studio)

1. Buat akun di github.com jika belum punya.
2. Klik **New repository** → beri nama, misalnya `kalender-kerja` → pilih **Private** → **Create repository**.
3. Klik **uploading an existing file**, lalu seret **semua isi** folder `kalender-kerja` (termasuk folder `.github`, `assets`, `scripts`).
   > Folder `.github` tersembunyi di Windows/Mac. Aktifkan "tampilkan file tersembunyi" (Windows: View → Hidden items, Mac: Cmd+Shift+.) supaya ikut terunggah.
4. Klik **Commit changes**.
5. Buka tab **Actions** → pilih **Build APK** → **Run workflow** → **Run workflow**.
6. Tunggu sampai tanda centang hijau (± 5–8 menit). Klik hasil build tersebut → bagian **Artifacts** → unduh **kalender-kerja-apk** (berupa .zip berisi `app-debug.apk`).
7. Kirim `app-debug.apk` ke HP (WhatsApp, Drive, kabel), buka, lalu izinkan **Install dari sumber tidak dikenal**.

Setiap kali file diubah dan diunggah ulang ke GitHub, APK baru dibuat otomatis.

---

## Jalur B: build di komputer dengan Android Studio

### Yang perlu dipasang (sekali saja)
- **Node.js 20 atau lebih baru**: nodejs.org (pilih LTS).
- **Android Studio**: developer.android.com/studio. Saat pertama dibuka, ikuti wizard sampai Android SDK terpasang. JDK 21 sudah termasuk di dalamnya.

### Perintah (jalankan di folder `kalender-kerja`, lewat Terminal / Command Prompt)

```bash
npm install                 # unduh Capacitor dan library Excel
npm run build               # salin file web ke folder www/
npx cap add android         # buat proyek Android (sekali saja)
npm run android:icons       # buat ikon & splash dari folder assets/
npx cap sync android        # masukkan file web ke proyek Android
npx cap open android        # buka di Android Studio
```

Di Android Studio:
1. Tunggu proses **Gradle sync** selesai (lihat bar bawah; pertama kali bisa 5–10 menit).
2. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. Klik **locate** pada notifikasi. File ada di `android/app/build/outputs/apk/debug/app-debug.apk`.

Atau langsung uji di HP: aktifkan **Opsi pengembang → USB debugging**, sambungkan kabel, lalu klik tombol ▶ (Run) di Android Studio.

### Setelah mengubah file web
```bash
npm run android:sync        # lalu Build APK lagi di Android Studio
```

### APK rilis (untuk dibagikan luas / Play Store)
Di Android Studio: **Build → Generate Signed App Bundle / APK** → buat keystore baru → pilih **release**.
Simpan file keystore dan kata sandinya baik-baik. Tanpa itu aplikasi tidak bisa diperbarui di Play Store.
Untuk Play Store pilih **Android App Bundle (.aab)**; perlu akun Google Play Console (biaya sekali US$25).

---

## Perbedaan versi aplikasi dengan versi web

- **Export Excel** di aplikasi membuka menu **Bagikan**: pilih Drive, WhatsApp, File, Gmail, dan seterusnya untuk menyimpan atau mengirim file.
- **Tombol Kembali** Android menutup form, dialog, chat, atau filter terlebih dahulu; jika tidak ada yang terbuka, aplikasi diminimalkan.
- Saat aplikasi dibuka kembali, data dan chat langsung dimuat ulang dari Google Sheets.
- Library Excel tertanam di aplikasi, jadi export tetap bisa tanpa internet. Data kalender tetap butuh internet untuk sinkron (tersimpan sementara di HP saat offline).

## Mengganti nama, ID, atau ikon aplikasi

- Nama dan ID: ubah `appName` dan `appId` di `capacitor.config.json` **sebelum** `npx cap add android`.
  `appId` harus unik jika masuk Play Store (contoh `com.namakantor.kalender`).
- Ikon: ganti `assets/icon-only.png`, `icon-foreground.png`, `icon-background.png` (1024×1024) dan `splash.png` (2732×2732), lalu `npm run android:icons`.

## Jika ada masalah

- **`npx cap add android` gagal: "android platform already exists"**: folder `android/` sudah ada, lewati langkah itu.
- **Gradle error soal Java/JDK**: di Android Studio, Settings → Build Tools → Gradle → Gradle JDK pilih versi **21**.
- **Aplikasi terbuka tapi tidak tersambung ke Sheets**: cek Langkah 0, lalu `npm run android:sync` dan build ulang.
- **Konten tertutup status bar di atas**: perbarui **Android System WebView** dan **Chrome** di Play Store, lalu buka ulang aplikasi.

/**
 * Kalender Kegiatan Kerja — backend Google Apps Script.
 *
 * Data disimpan di Google Sheet yang menjadi "rumah" script ini:
 *   - Sheet "Kegiatan"        : satu baris per kegiatan (sumber data utama)
 *   - Sheet "Catatan Revisi"  : satu baris per catatan revisi (dibuat ulang otomatis, hanya untuk dibaca)
 *
 * Cara pasang ada di README.md (bagian "Hubungkan ke Google Sheets").
 */

// Opsional: isi dengan kata sandi bebas, lalu isi kata sandi yang sama di web (menu Google Sheets).
// Biarkan kosong jika tidak memakai kunci.
var TOKEN = '';

// Hanya perlu diisi jika script dibuat terpisah di script.google.com (bukan lewat Ekstensi → Apps Script di Sheet).
// Ambil dari URL Sheet: https://docs.google.com/spreadsheets/d/<ID_INI>/edit
var SPREADSHEET_ID = '';

var SHEET_ITEMS = 'Kegiatan';
var SHEET_REV = 'Catatan Revisi';

var HEAD = ['ID', 'Tanggal', 'Hari', 'Kegiatan', 'Kategori', 'Prioritas', 'Status', 'Proyek', 'PIC',
  'Catatan', 'Revisi terbuka', 'Data revisi (JSON)', 'Diperbarui', 'Versi', 'Diubah oleh'];
var SHEET_CHAT = 'Chat';
var HEAD_CHAT = ['ID', 'Waktu', 'Nama', 'Pesan', 'ts'];
var HEAD_REV = ['ID kegiatan', 'Tanggal kegiatan', 'Kegiatan', 'Revisi ke', 'Tanggal dicatat', 'Catatan revisi', 'Status revisi'];

var CH = { rapat: 'Rapat', desain: 'Desain', konten: 'Konten', website: 'Website', video: 'Video & Foto',
  klien: 'Klien & Mitra', laporan: 'Laporan', admin: 'Administrasi', lainnya: 'Lainnya' };
var ST = { rencana: 'Rencana', kerjakan: 'Dikerjakan', review: 'Review', revisi: 'Revisi', selesai: 'Selesai' };
var DAYS = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

/* ---------------- endpoint web ---------------- */

function doGet(e) {
  var p = (e && e.parameter) || {};
  return handle_({ action: p.action || 'list', token: p.token || '' });
}

function doPost(e) {
  var body = {};
  try { body = JSON.parse((e && e.postData && e.postData.contents) || '{}'); }
  catch (err) { return json_({ ok: false, error: 'Body bukan JSON yang valid.' }); }
  return handle_(body);
}

function handle_(req) {
  try {
    if (TOKEN && req.token !== TOKEN) return json_({ ok: false, error: 'Kunci (token) salah.' });
    var action = req.action || 'list';
    if (action === 'ping') return json_({ ok: true, name: ss_().getName() });
    if (action === 'list') return json_({ ok: true, items: readItems_() });
    if (action === 'chatList') return json_(chatList_(Number(req.after) || 0));
    if (action === 'chatSend') return json_(chatSend_(req));

    var lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      var ops;
      if (action === 'batch') ops = req.ops || [];
      else if (action === 'upsert') ops = [{ op: 'upsert', item: req.item }];
      else if (action === 'delete') ops = [{ op: 'delete', id: req.id }];
      else return json_({ ok: false, error: 'Aksi tidak dikenal: ' + action });
      var r = applyOps_(ops, String(req.by || '').slice(0, 40));
      return json_({ ok: true, applied: r.applied, vers: r.vers, conflicts: r.conflicts });
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------------- sheet helpers ---------------- */

function ss_() {
  var ss = SPREADSHEET_ID ? SpreadsheetApp.openById(SPREADSHEET_ID) : SpreadsheetApp.getActive();
  if (!ss) throw new Error('Script tidak terhubung ke Google Sheet. Buat script lewat Ekstensi → Apps Script di Sheet, atau isi SPREADSHEET_ID di Code.gs.');
  return ss;
}

function sheet_(name, head) {
  var ss = ss_();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#FFE680');
    sh.setFrozenRows(1);
  }
  return sh;
}
function itemsSheet_() {
  var sh = sheet_(SHEET_ITEMS, HEAD);
  if (sh.getRange(1, HEAD.length).getValue() !== HEAD[HEAD.length - 1]) {
    sh.getRange(1, 1, 1, HEAD.length).setValues([HEAD]).setFontWeight('bold').setBackground('#FFE680'); // tambah kolom baru di sheet lama
  }
  if (sh.getMaxColumns() >= 2) sh.getRange('B:B').setNumberFormat('dd/mm/yyyy');
  return sh;
}
function tz_() { return ss_().getSpreadsheetTimeZone(); }

function toISO_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, tz_(), 'yyyy-MM-dd');
  var s = String(v || '').trim();
  var m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return m[1] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[3]).slice(-2);
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); // dd/mm/yyyy
  if (m) return m[3] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
  return '';
}
function toDate_(iso) { return Utilities.parseDate(iso, tz_(), 'yyyy-MM-dd'); }
function dayName_(iso) { var p = iso.split('-'); return DAYS[new Date(+p[0], +p[1] - 1, +p[2]).getDay()]; }

function idFromName_(map, v, fallback) {
  var s = String(v || '').trim();
  if (!s) return fallback;
  if (map[s]) return s;
  for (var k in map) if (map[k].toLowerCase() === s.toLowerCase()) return k;
  return s;
}

/* ---------------- read ---------------- */

function readItems_() {
  var sh = itemsSheet_();
  var last = sh.getLastRow();
  if (last < 2) return [];
  var vals = sh.getRange(2, 1, last - 1, HEAD.length).getValues();
  var out = [];
  vals.forEach(function (r, i) {
    var id = String(r[0] || '').trim();
    var title = String(r[3] || '').trim();
    if (!id && !title) return;
    if (!id) {
      // baris yang diketik manual di Sheet: beri ID tetap supaya bisa diubah dari web
      id = 's' + Utilities.getUuid().replace(/-/g, '').slice(0, 12);
      sh.getRange(i + 2, 1).setValue(id);
    }
    out.push(itemFromRow_(r, id));
  });
  return out;
}

function verOf_(r) {
  return Number(r[13]) || (r[12] instanceof Date ? r[12].getTime() : 0);
}

function itemFromRow_(r, id) {
  var revs = [];
  try { revs = JSON.parse(r[11] || '[]') || []; } catch (e) { revs = []; }
  return {
    id: id || String(r[0]),
    date: toISO_(r[1]),
    title: String(r[3] || '').trim(),
    channel: idFromName_(CH, r[4], 'lainnya'),
    format: String(r[5] || 'Sedang'),
    status: idFromName_(ST, r[6], 'rencana'),
    campaign: String(r[7] || ''),
    pic: String(r[8] || ''),
    notes: String(r[9] || ''),
    revisions: Array.isArray(revs) ? revs : [],
    ver: verOf_(r),
    by: String(r[14] || '')
  };
}

/* ---------------- write ---------------- */

function rowFor_(it, ver, by) {
  var iso = toISO_(it.date) || Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd');
  var revs = (Array.isArray(it.revisions) ? it.revisions : []).map(function (r) {
    return { id: String(r.id || ''), date: toISO_(r.date) || iso, text: String(r.text || ''), done: !!r.done };
  });
  var open = revs.filter(function (r) { return !r.done; }).length;
  return [
    String(it.id), toDate_(iso), dayName_(iso), String(it.title || '(tanpa judul)'),
    CH[it.channel] || String(it.channel || ''), String(it.format || 'Sedang'),
    ST[it.status] || String(it.status || ''), String(it.campaign || ''), String(it.pic || ''),
    String(it.notes || ''), open, JSON.stringify(revs), new Date(ver), ver, String(by || '')
  ];
}

/*
 * Setiap op membawa "ver": versi kegiatan yang dilihat pengguna saat mulai mengedit.
 * Jika versi di Sheet lebih baru (sudah diubah orang lain), op tidak dijalankan
 * dan dikembalikan sebagai "konflik" supaya pengguna memilih. force:true melewati pengecekan.
 */
function applyOps_(ops, by) {
  var res = { applied: 0, vers: {}, conflicts: [] };
  if (!ops.length) return res;
  var sh = itemsSheet_();
  var last = sh.getLastRow();
  var data = last >= 2 ? sh.getRange(2, 1, last - 1, HEAD.length).getValues() : [];
  var ids = data.map(function (r) { return String(r[0]); });
  var vers = data.map(verOf_);
  var touched = {};
  var clock = Date.now();
  function nextVer() { clock = Math.max(Date.now(), clock + 1); return clock; }
  function current(idx) { return itemFromRow_(sh.getRange(idx + 2, 1, 1, HEAD.length).getValues()[0]); }

  ops.forEach(function (o) {
    if (!o) return;
    if (o.op === 'upsert' && o.item && o.item.id) {
      var id = String(o.item.id);
      var idx = ids.indexOf(id);
      var base = Number(o.item.ver) || 0;
      if (!o.force && !touched[id] && base > 0) {
        if (idx < 0) { res.conflicts.push({ id: id, op: 'upsert', server: null }); return; }          // sudah dihapus orang lain
        if (vers[idx] > base) { res.conflicts.push({ id: id, op: 'upsert', server: current(idx) }); return; } // sudah diubah orang lain
      }
      var v = nextVer();
      var row = rowFor_(o.item, v, by);
      if (idx >= 0) {
        sh.getRange(idx + 2, 1, 1, HEAD.length).setValues([row]);
        vers[idx] = v;
      } else {
        sh.appendRow(row);
        ids.push(id); vers.push(v);
      }
      touched[id] = 1; res.vers[id] = v; res.applied++;
    } else if (o.op === 'delete' && o.id) {
      var did = String(o.id);
      var di = ids.indexOf(did);
      if (di >= 0) {
        var dbase = Number(o.ver) || 0;
        if (!o.force && !touched[did] && dbase > 0 && vers[di] > dbase) {
          res.conflicts.push({ id: did, op: 'delete', server: current(di) }); return;
        }
        sh.deleteRow(di + 2);
        ids.splice(di, 1); vers.splice(di, 1);
      }
      touched[did] = 1; res.applied++;
    }
  });

  sortItems_(sh);
  rebuildRevisions_();
  return res;
}

function sortItems_(sh) {
  var last = sh.getLastRow();
  if (last > 2) sh.getRange(2, 1, last - 1, HEAD.length).sort([{ column: 2, ascending: true }, { column: 4, ascending: true }]);
}

function rebuildRevisions_() {
  var sh = sheet_(SHEET_REV, HEAD_REV);
  var items = readItems_();
  var rows = [];
  items.forEach(function (it) {
    (it.revisions || []).forEach(function (r, k) {
      rows.push([it.id, toDate_(it.date), it.title, k + 1, toDate_(toISO_(r.date) || it.date), r.text, r.done ? 'Selesai' : 'Terbuka']);
    });
  });
  var last = sh.getLastRow();
  if (last >= 2) sh.getRange(2, 1, last - 1, HEAD_REV.length).clearContent();
  if (rows.length) {
    sh.getRange(2, 1, rows.length, HEAD_REV.length).setValues(rows);
    sh.getRange(2, 2, rows.length, 1).setNumberFormat('dd/mm/yyyy');
    sh.getRange(2, 5, rows.length, 1).setNumberFormat('dd/mm/yyyy');
  }
}

/* ---------------- chat ---------------- */

function chatSheet_() {
  var sh = sheet_(SHEET_CHAT, HEAD_CHAT);
  return sh;
}

// Pesan setelah waktu "after" (milidetik). after=0 → 100 pesan terakhir.
function chatList_(after) {
  var cache = CacheService.getScriptCache();
  var lastTs = Number(cache.get('chat_last_ts') || 0);
  if (after && lastTs && after >= lastTs) return { ok: true, messages: [], now: Date.now() }; // tidak ada pesan baru, tanpa membaca sheet
  var sh = chatSheet_();
  var last = sh.getLastRow();
  if (last < 2) return { ok: true, messages: [], now: Date.now() };
  var n = Math.min(last - 1, 300);
  var vals = sh.getRange(last - n + 1, 1, n, HEAD_CHAT.length).getValues();
  var msgs = [];
  vals.forEach(function (r) {
    var ts = Number(r[4]) || (r[1] instanceof Date ? r[1].getTime() : 0);
    if (!r[3] || ts <= after) return;
    msgs.push({ id: String(r[0]), ts: ts, name: String(r[2] || 'Anonim'), text: String(r[3]) });
  });
  msgs.sort(function (a, b) { return a.ts - b.ts; });
  if (!after) msgs = msgs.slice(-100);
  if (msgs.length) cache.put('chat_last_ts', String(Math.max(lastTs, msgs[msgs.length - 1].ts)), 21600);
  return { ok: true, messages: msgs, now: Date.now() };
}

function chatSend_(req) {
  var text = String(req.text || '').trim().slice(0, 1000);
  var name = String(req.name || '').trim().slice(0, 40) || 'Anonim';
  if (!text) return { ok: false, error: 'Pesan kosong.' };
  var id = String(req.id || Utilities.getUuid());
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var ts = Date.now();
    var cache = CacheService.getScriptCache();
    var prev = Number(cache.get('chat_last_ts') || 0);
    if (ts <= prev) ts = prev + 1; // urutan tetap unik
    chatSheet_().appendRow([id, new Date(ts), name, text, ts]);
    cache.put('chat_last_ts', String(ts), 21600);
    return { ok: true, message: { id: id, ts: ts, name: name, text: text } };
  } finally {
    lock.releaseLock();
  }
}

/** Jalankan sekali dari editor (pilih fungsi "setup" lalu Run) untuk membuat sheet dan memberi izin. */
function setup() {
  itemsSheet_();
  sheet_(SHEET_REV, HEAD_REV);
  chatSheet_().getRange('B:B').setNumberFormat('dd/mm/yyyy hh:mm');
  rebuildRevisions_();
  Logger.log('Siap. Sheet "%s" dan "%s" sudah dibuat.', SHEET_ITEMS, SHEET_REV);
}

/** Otomatis berjalan saat Sheet diedit langsung: naikkan versi baris supaya web tahu ada perubahan. */
function onEdit(e) {
  if (!e || !e.range) return;
  var sh = e.range.getSheet();
  if (sh.getName() !== SHEET_ITEMS) return;
  var r0 = Math.max(2, e.range.getRow());
  var r1 = e.range.getRow() + e.range.getNumRows() - 1;
  if (r1 < r0) return;
  var c0 = e.range.getColumn(), c1 = c0 + e.range.getNumColumns() - 1;
  if (c0 >= 13) return; // yang diedit hanya kolom Diperbarui/Versi/Diubah oleh
  var now = Date.now(), rows = [];
  for (var r = r0; r <= r1; r++) rows.push([new Date(now), now, 'Edit langsung di Sheet']);
  sh.getRange(r0, 13, rows.length, 3).setValues(rows);
}

// Menyalin file web ke folder www/ untuk dibungkus Capacitor menjadi aplikasi Android.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const out = path.join(root, 'www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'vendor'), { recursive: true });
for (const d of ['css', 'js']) fs.cpSync(path.join(root, d), path.join(out, d), { recursive: true });

// Library Excel disalin ke dalam aplikasi supaya export tetap jalan tanpa internet.
const xlsx = path.join(root, 'node_modules', 'xlsx', 'dist', 'xlsx.full.min.js');
if (!fs.existsSync(xlsx)) { console.error('xlsx belum terpasang. Jalankan: npm install'); process.exit(1); }
fs.copyFileSync(xlsx, path.join(out, 'vendor', 'xlsx.full.min.js'));

let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
html = html
  .replace(/<script src="https:\/\/cdnjs[^"]*xlsx[^"]*"><\/script>\s*/, '')
  .replace(/<script>window\.XLSX\|\|document\.write[^\n]*<\/script>/, '<script src="vendor/xlsx.full.min.js"></script>');
fs.writeFileSync(path.join(out, 'index.html'), html);

const m = html.match(/scriptUrl:\s*'([^']*)'[\s\S]*?deploymentId:\s*'([^']*)'/);
if (!m || (!m[1] && !m[2])) {
  console.warn('\n  PERINGATAN: scriptUrl / deploymentId di index.html masih kosong.');
  console.warn('  Aplikasi tetap jalan, tapi pengguna harus mengisi URL lewat tombol "Google Sheets".\n');
}
console.log('Selesai: file web disalin ke www/');

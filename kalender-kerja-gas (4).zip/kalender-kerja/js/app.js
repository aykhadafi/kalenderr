(function(){
'use strict';

/* ---------- reference data ---------- */
var CH=[
  {id:'rapat',name:'Rapat',c:'#3B76E8'},
  {id:'desain',name:'Desain',c:'#D6336C'},
  {id:'konten',name:'Konten',c:'#E8590C'},
  {id:'website',name:'Website',c:'#0CA678'},
  {id:'video',name:'Video & Foto',c:'#AE3EC9'},
  {id:'klien',name:'Klien & Mitra',c:'#228BE6'},
  {id:'laporan',name:'Laporan',c:'#C99700'},
  {id:'admin',name:'Administrasi',c:'#7950F2'},
  {id:'lainnya',name:'Lainnya',c:'#8A93A3'}
];
var ST=[
  {id:'rencana',name:'Rencana',c:'#8A93A3'},
  {id:'kerjakan',name:'Dikerjakan',c:'#E08A00'},
  {id:'review',name:'Review',c:'#3B76E8'},
  {id:'revisi',name:'Revisi',c:'#D6336C'},
  {id:'selesai',name:'Selesai',c:'#2F9E44'}
];
var FORMATS=['Tinggi','Sedang','Rendah'];
var MONTHS=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
var MON_S=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
var DAYS=['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'];
var DAYS_S=['Sen','Sel','Rab','Kam','Jum','Sab','Min'];
var FIXED={'01-01':'Tahun Baru','04-21':'Hari Kartini','05-01':'Hari Buruh','06-01':'Hari Pancasila','08-17':'HUT RI','10-28':'Sumpah Pemuda','11-10':'Hari Pahlawan','12-25':'Natal'};

/* ---------- helpers ---------- */
function $(s,r){return (r||document).querySelector(s)}
function pad(n){return String(n).padStart(2,'0')}
function toISO(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
function parseISO(s){var p=s.split('-').map(Number);return new Date(p[0],p[1]-1,p[2])}
function addDays(d,n){return new Date(d.getFullYear(),d.getMonth(),d.getDate()+n)}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
var nf=new Intl.NumberFormat('id-ID');
function rp(n){return 'Rp '+nf.format(Math.round(Number(n)||0))}
function uid(){return 'k'+Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function dayName(iso){return DAYS[(parseISO(iso).getDay()+6)%7]}
function longDate(iso){var d=parseISO(iso);return dayName(iso)+', '+d.getDate()+' '+MON_S[d.getMonth()]+' '+d.getFullYear()}
function blackFriday(y){var f=new Date(y,10,1).getDay();var th=1+((4-f+7)%7)+21;return th+1}
function keyLabel(y,m,d){
  var k=pad(m+1)+'-'+pad(d);
  if(FIXED[k]) return FIXED[k];
  return '';
}
function chOf(id){for(var i=0;i<CH.length;i++)if(CH[i].id===id)return CH[i];return {id:id,name:id||'-',c:'#8A93A3'}}
function stOf(id){for(var i=0;i<ST.length;i++)if(ST[i].id===id)return ST[i];return ST[0]}
function openRev(it){return (it.revisions||[]).filter(function(r){return !r.done}).length}
function revText(it){return (it.revisions||[]).map(function(r,k){return (k+1)+'. '+r.text+(r.done?' [selesai]':' [terbuka]')}).join('; ')}
function chIdx(id){for(var i=0;i<CH.length;i++)if(CH[i].id===id)return i;return 99}
function cmp(a,b){return a.date.localeCompare(b.date)||chIdx(a.channel)-chIdx(b.channel)||String(a.title).localeCompare(String(b.title))}

/* ---------- state ---------- */
var today=new Date(), TODAY=toISO(today);
var S={items:[],view:'month',y:today.getFullYear(),m:today.getMonth(),sel:TODAY,fCh:new Set(),fSt:'',fRev:false,q:'',scope:'month'};
var dirty=false, storeMode='memory';
var revDraft=[], editingId=null, lastFocus=null, delTimer=null, toastTimer=null;

function seeds(){
  var t=new Date();
  function mk(n,title,ch,pri,st,proj,pic,notes,revs){return {id:uid(),date:toISO(addDays(t,n)),title:title,channel:ch,format:pri,status:st,campaign:proj,pic:pic,notes:notes||'',revisions:(revs||[]).map(function(r){return {id:uid(),date:toISO(addDays(t,n-1)),text:r[0],done:r[1]}}),example:true}}
  return [
    mk(-6,'Rapat kickoff proyek website','rapat','Sedang','selesai','Website Baru','Dinda','Agenda: ruang lingkup, jadwal, pembagian tugas.'),
    mk(-3,'Desain banner beranda','desain','Tinggi','selesai','Website Baru','Raka','',[['Perbesar logo di pojok kiri atas',true],['Ganti warna tombol menjadi biru tua',true]]),
    mk(0,'Draft artikel blog bulanan','konten','Sedang','revisi','Konten Bulanan','Sari','Target 800 kata.',[['Judul terlalu panjang, ringkas menjadi maksimal 60 karakter',false],['Tambahkan satu contoh kasus di bagian kedua',false]]),
    mk(1,'Edit video profil 30 detik','video','Tinggi','kerjakan','Video Profil','Raka','Format 1920x1080, teks bahasa Indonesia.',[['Musik latar terlalu keras di detik 10 sampai 15',false]]),
    mk(2,'Presentasi progres ke klien','klien','Tinggi','review','Website Baru','Dinda','Siapkan slide ringkas, maksimal 10 halaman.',[['Tambahkan slide perbandingan sebelum dan sesudah',false]]),
    mk(4,'Perbaikan tampilan beranda di handphone','website','Tinggi','rencana','Website Baru','Sari'),
    mk(6,'Laporan kegiatan mingguan','laporan','Sedang','rencana','Rutin','Dinda'),
    mk(9,'Rekap dokumen dan arsip','admin','Rendah','rencana','Rutin','Sari'),
    mk(12,'Rapat evaluasi bulanan','rapat','Sedang','rencana','Rutin','Dinda','')
  ];
}
function normalize(it){
  var revs=Array.isArray(it.revisions)?it.revisions.map(function(r){return {id:r.id||uid(),date:r.date||TODAY,text:String(r.text||''),done:!!r.done}}):[];
  return {id:it.id||uid(),date:it.date||TODAY,title:it.title||'(tanpa judul)',channel:it.channel||'rapat',format:it.format||'Sedang',status:it.status||'rencana',campaign:it.campaign||'',pic:it.pic||'',notes:it.notes||'',revisions:revs,example:!!it.example,ver:Number(it.ver)||0,by:it.by||''};
}

/* ---------- storage ---------- */
var LS_KEY='kalender-kerja-v1';
function lsRead(){try{var r=localStorage.getItem(LS_KEY);return r?JSON.parse(r):null}catch(e){return null}}
function lsWrite(){try{localStorage.setItem(LS_KEY,JSON.stringify({items:S.items}));return true}catch(e){return false}}
function lsAvailable(){try{localStorage.setItem('kk-test','1');localStorage.removeItem('kk-test');return true}catch(e){return false}}

/* ops: daftar perubahan untuk dikirim ke Google Sheets, contoh [{op:'upsert',item:{...}}] atau [{op:'delete',id:'...'}] */
function changed(ops){
  dirty=true;
  storeMode=lsWrite()?'local':'memory';
  if(gasOn()&&ops&&ops.length){enqueue(ops)}
  renderStatus();
}
function renderStatus(){
  var el=$('#saveState'),txt,cls='';
  if(!gasOn()){
    txt=storeMode==='local'?'Tersimpan di browser ini':'Belum tersimpan permanen';
  } else if(gas.state==='loading'){txt='Memuat dari Google Sheets…';cls='busy'}
  else if(gas.state==='saving'){txt='Menyimpan ke Google Sheets…';cls='busy'}
  else if(gas.state==='error'){txt='Gagal sinkron'+(gas.queue.length?' · '+gas.queue.length+' perubahan menunggu':'')+' · coba lagi';cls='err'}
  else if(gas.queue.length){txt=gas.queue.length+' perubahan menunggu dikirim';cls='busy'}
  else {txt='Tersinkron dengan Google Sheets'+(gas.last?' · '+pad(gas.last.getHours())+'.'+pad(gas.last.getMinutes()):'');cls='ok'}
  el.className='savestate'+(cls?' '+cls:'');
  el.innerHTML=(gasOn()?'<i></i>':'')+esc(txt);
  el.title=gasOn()?(gas.state==='error'&&gas.err?gas.err:'Pengaturan Google Sheets'):'Hubungkan ke Google Sheets';
}

/* ---------- Google Apps Script sync ---------- */
var CFG_KEY='kalender-kerja-gas', Q_KEY='kalender-kerja-queue';
var gas={url:'',token:'',queue:[],busy:false,state:'off',err:'',last:null,lastPull:0};
function gasOn(){return !!gas.url}
function validUrl(u){return /^https:\/\/script\.google(usercontent)?\.com\/.+\/exec(\?.*)?$/.test(u)}
var gasFixed=false; // true jika URL diatur di index.html
function gasLoadCfg(){
  var c=window.KK_CONFIG||{};
  var url=String(c.scriptUrl||'').trim(), dep=String(c.deploymentId||'').trim();
  if(!url&&dep)url='https://script.google.com/macros/s/'+dep+'/exec';
  if(url){
    gasFixed=true;gas.url=url;gas.token=String(c.token||'').trim();
  } else {
    try{var s=JSON.parse(localStorage.getItem(CFG_KEY)||'null');if(s){if(typeof s.url==='string')gas.url=s.url;if(typeof s.token==='string')gas.token=s.token}}catch(e){}
  }
  try{gas.queue=JSON.parse(localStorage.getItem(Q_KEY)||'[]')||[]}catch(e){gas.queue=[]}
  if(!Array.isArray(gas.queue))gas.queue=[];
  try{var lastUrl=localStorage.getItem(CFG_KEY+'-last');if(lastUrl!==gas.url){gas.queue=[];localStorage.setItem(CFG_KEY+'-last',gas.url);qSave()}}catch(e){}
}
function gasSaveCfg(){try{localStorage.setItem(CFG_KEY,JSON.stringify({url:gas.url,token:gas.token}))}catch(e){}}
function qSave(){try{localStorage.setItem(Q_KEY,JSON.stringify(gas.queue))}catch(e){}}
function setSync(state,err){gas.state=state;gas.err=err||'';renderStatus()}

function gasCall(payload,url,token){
  var body=Object.assign({},payload,{token:token!=null?token:gas.token});
  // text/plain agar browser tidak mengirim preflight CORS (Apps Script tidak melayani OPTIONS)
  return fetch(url||gas.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(body),redirect:'follow'})
    .then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.text()})
    .then(function(t){
      var j;try{j=JSON.parse(t)}catch(e){throw new Error('Respon bukan JSON. Pastikan Web App di-deploy dengan akses "Siapa saja" (Anyone).')}
      if(!j.ok){
        var m=j.error||'Permintaan ditolak.';
        if(/Aksi tidak dikenal/.test(m))m='Code.gs di Apps Script masih versi lama. Tempel Code.gs terbaru, simpan, lalu Deploy → Manage deployments → Edit → Version: New version → Deploy.';
        throw new Error(m);
      }
      return j;
    },function(e){
      if(e&&e.message&&e.message.indexOf('HTTP')===0)throw e;
      throw new Error('Tidak bisa menghubungi Apps Script. Periksa URL, koneksi internet, dan akses deploy "Siapa saja".');
    });
}
function clean(it){return {ver:Number(it.ver)||0,id:it.id,date:it.date,title:it.title,channel:it.channel,format:it.format,status:it.status,campaign:it.campaign,pic:it.pic,notes:it.notes,revisions:(it.revisions||[]).map(function(r){return {id:r.id,date:r.date,text:r.text,done:!!r.done}})}}
function enqueue(ops){
  ops.forEach(function(o){gas.queue.push(o.op==='upsert'?{op:'upsert',item:clean(o.item),force:!!o.force}:o)});
  qSave();flush();
}
function flush(){
  if(!gasOn()||gas.busy||!gas.queue.length)return Promise.resolve();
  gas.busy=true;setSync('saving');
  var batch=gas.queue.slice(0,50);
  return gasCall({action:'batch',ops:batch,by:myName()}).then(function(j){
    gas.queue=gas.queue.slice(batch.length);
    applyVers(j.vers||{});
    qSave();
    (j.conflicts||[]).forEach(function(c){
      var op=batch.filter(function(o){return (o.id||(o.item&&o.item.id))===c.id}).pop();
      if(op)addConflict(c,op);
    });
    gas.busy=false;gas.last=new Date();setSync('ok');
    if(gas.queue.length)return flush();
  },function(e){gas.busy=false;setSync('error',e.message)});
}
function pull(force){
  if(!gasOn())return Promise.resolve();
  if(gas.busy)return Promise.resolve();
  if(gas.queue.length)return flush().then(function(){if(!gas.queue.length&&!gas.busy)return pull(force)});
  if(!force&&(!$('#overlay').hidden||!$('#conflictOverlay').hidden))return Promise.resolve(); // jangan ganggu saat form/dialog terbuka
  setSync('loading');
  return gasCall({action:'list'}).then(function(j){
    gas.lastPull=Date.now();
    if(gas.queue.length||gas.busy){setSync('ok');return} // ada perubahan lokal baru selama memuat
    S.items=(j.items||[]).filter(function(i){return i.date}).map(normalize);
    lsWrite();gas.last=new Date();setSync('ok');render();
  },function(e){setSync('error',e.message)});
}

/* dialog pengaturan */
var gasLastFocus=null;
function gasMsg(msg,kind){var el=$('#gasStatus');el.textContent=msg||'';el.className='gas-status'+(kind?' '+kind:'')}
function openGas(){
  gasLastFocus=document.activeElement;
  $('#g-url').value=gas.url;$('#g-token').value=gas.token;$('#e-gurl').hidden=true;
  $('#g-url').readOnly=$('#g-token').readOnly=gasFixed;
  $('#gasSave').hidden=gasFixed;
  $('#gasPush').hidden=$('#gasPull').hidden=!gasOn();
  $('#gasOff').hidden=!gasOn()||gasFixed;
  $('#gasFixedNote').hidden=!gasFixed;
  gasMsg(gasOn()?(gas.state==='error'?'Error terakhir: '+gas.err:'Terhubung. '+S.items.length+' kegiatan di Sheet.'):'',gas.state==='error'?'err':'');
  $('#gasOverlay').hidden=false;
  setTimeout(function(){$('#g-url').focus()},0);
}
function closeGas(){
  $('#gasOverlay').hidden=true;
  if(gasLastFocus&&gasLastFocus.focus&&document.contains(gasLastFocus))gasLastFocus.focus();
}
function gasFormValues(){
  var u=$('#g-url').value.trim(),t=$('#g-token').value.trim();
  var ok=validUrl(u);$('#e-gurl').hidden=ok;
  return ok?{url:u,token:t}:null;
}
function gasTest(){
  var v=gasFormValues();if(!v){$('#g-url').focus();return}
  gasMsg('Menguji koneksi…');
  gasCall({action:'ping'},v.url,v.token).then(function(j){gasMsg('Berhasil terhubung ke spreadsheet "'+j.name+'".','ok')},function(e){gasMsg(e.message,'err')});
}
function gasConnect(e){
  e.preventDefault();
  var v=gasFormValues();if(!v){$('#g-url').focus();return}
  gasMsg('Menghubungkan…');$('#gasSave').disabled=true;
  var local=S.items.filter(function(i){return !i.example});
  gasCall({action:'list'},v.url,v.token).then(function(j){
    var wasOn=gasOn()&&gas.url===v.url;
    gas.url=v.url;gas.token=v.token;gasSaveCfg();
    var remote=j.items||[];
    var ids={};remote.forEach(function(r){ids[r.id]=1});
    var missing=wasOn?[]:local.filter(function(i){return !ids[i.id]});
    var p=missing.length
      ? gasCall({action:'batch',ops:missing.map(function(i){return {op:'upsert',item:clean(i)}})})
      : Promise.resolve();
    return p.then(function(){
      gas.queue=gas.queue.filter(function(){return wasOn});qSave();
      return pull(true);
    }).then(function(){
      if(gas.state==='error')throw new Error(gas.err);
      gasMsg('Terhubung'+(missing.length?'. '+missing.length+' kegiatan dari browser ini ikut dikirim ke Sheet.':'.'),'ok');
      $('#gasPush').hidden=$('#gasPull').hidden=$('#gasOff').hidden=false;
      toast('Terhubung ke Google Sheets.');
      chat.loaded=false;chatHeader();chatRender();chatPoll().then(chatSchedule);
    });
  }).catch(function(err){gasMsg(err.message,'err')}).then(function(){$('#gasSave').disabled=false});
}
function gasPushAll(){
  var list=S.items.filter(function(i){return !i.example});
  if(!list.length){gasMsg('Tidak ada kegiatan untuk dikirim.');return}
  gasMsg('Mengirim '+list.length+' kegiatan…');
  enqueue(list.map(function(i){return {op:'upsert',item:i}}));
  var wait=setInterval(function(){
    if(gas.busy)return;clearInterval(wait);
    if(gas.state==='error')gasMsg(gas.err,'err');else gasMsg(list.length+' kegiatan terkirim ke Sheet.','ok');
  },300);
}
function gasDisconnect(){
  gas.url='';gas.token='';gas.queue=[];qSave();gasSaveCfg();setSync('off');
  $('#gasPush').hidden=$('#gasPull').hidden=$('#gasOff').hidden=true;
  $('#g-url').value='';$('#g-token').value='';
  gasMsg('Terputus. Data tetap tersimpan di browser ini.');
  clearTimeout(chat.timer);chatHeader();chatRender();
  render();
}

/* ---------- filtering ---------- */
function matches(it){
  if(S.fCh.size&&!S.fCh.has(it.channel)) return false;
  if(S.fSt&&it.status!==S.fSt) return false;
  if(S.fRev&&!openRev(it)) return false;
  if(S.q){
    var hay=(it.title+' '+it.campaign+' '+it.pic+' '+it.notes+' '+revText(it)).toLowerCase();
    if(hay.indexOf(S.q.toLowerCase())<0) return false;
  }
  return true;
}
function inMonth(it){var d=parseISO(it.date);return d.getFullYear()===S.y&&d.getMonth()===S.m}
function filtered(){return S.items.filter(matches)}
function scopeItems(){var f=filtered();return (S.view==='list'&&S.scope==='all')?f:f.filter(inMonth)}

/* ---------- render ---------- */
function render(){
  renderBar();renderSummary();renderFilterState();renderView();renderDay();renderBanner();renderStatus();
}
function renderBar(){
  $('#mtitle').innerHTML=MONTHS[S.m]+' <span>'+S.y+'</span>';
  $('#vMonth').setAttribute('aria-pressed',S.view==='month');
  $('#vList').setAttribute('aria-pressed',S.view==='list');
  $('#scopeSeg').hidden=S.view!=='list';
  $('#sMonth').setAttribute('aria-pressed',S.scope==='month');
  $('#sAll').setAttribute('aria-pressed',S.scope==='all');
  $('#layout').classList.toggle('listmode',S.view==='list');
}
function renderBanner(){$('#banner').hidden=!S.items.some(function(i){return i.example})}
function renderSummary(){
  var list=scopeItems();
  var openR=list.reduce(function(s,i){return s+openRev(i)},0);
  var label=(S.view==='list'&&S.scope==='all')?'Semua rencana':MONTHS[S.m]+' '+S.y;
  var counts=ST.map(function(s){return {s:s,n:list.filter(function(i){return i.status===s.id}).length}});
  var bar=list.length?counts.filter(function(c){return c.n>0}).map(function(c){return '<i style="--sc:'+c.s.c+';flex:'+c.n+'" title="'+esc(c.s.name)+': '+c.n+'"></i>'}).join(''):'';
  var legend=list.length?counts.map(function(c){return '<span style="--sc:'+c.s.c+'"><i></i>'+esc(c.s.name)+' <b>'+c.n+'</b></span>'}).join(''):'<span>Belum ada kegiatan. Klik tanggal lalu tambah kegiatan.</span>';
  $('#summary').innerHTML=
    '<div><span class="lbl">Kegiatan &middot; '+esc(label)+'</span><b>'+list.length+'</b></div>'+
    '<div><span class="lbl">Revisi terbuka</span><b>'+openR+'</b></div>'+
    '<div class="sum-status"><span class="lbl">Status</span><div class="stbar">'+bar+'</div><div class="legend">'+legend+'</div></div>';
}
function renderFilterState(){
  var btns=document.querySelectorAll('#chFilters .fch');
  for(var i=0;i<btns.length;i++){btns[i].setAttribute('aria-pressed',S.fCh.has(btns[i].dataset.ch))}
  $('#revFilter').setAttribute('aria-pressed',S.fRev);
  $('#resetFilter').hidden=!(S.fCh.size||S.fSt||S.q||S.fRev);
  var n=S.fCh.size+(S.fSt?1:0)+(S.q?1:0)+(S.fRev?1:0);
  var fc=$('#filterCount');fc.hidden=!n;fc.textContent=n;
}
function renderView(){ if(S.view==='list') renderList(); else renderMonth(); }

function chip(it){
  var c=chOf(it.channel),o=openRev(it);
  return '<span class="chip s-'+esc(it.status)+'" style="--c:'+c.c+'" title="'+esc(it.title)+(o?' ('+o+' revisi terbuka)':'')+'"><i class="dot"></i><span class="t">'+esc(it.title)+'</span>'+(o?'<b class="rv">'+o+'</b>':'')+'</span>';
}
function renderMonth(){
  var first=new Date(S.y,S.m,1);
  var lead=(first.getDay()+6)%7;
  var dim=new Date(S.y,S.m+1,0).getDate();
  var rows=Math.ceil((lead+dim)/7);
  var by={};
  filtered().forEach(function(it){(by[it.date]=by[it.date]||[]).push(it)});
  var h='<div class="grid" role="grid" aria-label="Kalender '+MONTHS[S.m]+' '+S.y+'">';
  for(var i=0;i<7;i++) h+='<div class="dow" role="columnheader">'+DAYS_S[i]+'</div>';
  for(var k=0;k<rows*7;k++){
    var d=new Date(S.y,S.m,1-lead+k), iso=toISO(d);
    var list=(by[iso]||[]).slice().sort(cmp);
    var shown=list.slice(0,3), more=list.length-shown.length;
    var key=keyLabel(d.getFullYear(),d.getMonth(),d.getDate());
    var cls='cell'+(d.getMonth()!==S.m?' out':'')+(iso===TODAY?' today':'')+(iso===S.sel?' sel':'')+(key?' hasKey':'');
    var aria=longDate(iso)+'. '+(list.length?list.length+' kegiatan':'Kosong')+(key?'. '+key:'');
    h+='<button type="button" class="'+cls+'" data-date="'+iso+'" aria-label="'+esc(aria)+'" aria-pressed="'+(iso===S.sel)+'"'+(iso===TODAY?' aria-current="date"':'')+'>'+
      '<span class="chead"><span class="num">'+d.getDate()+'</span>'+(key?'<span class="key">'+esc(key)+'</span>':'')+'</span>'+
      '<span class="chips">'+shown.map(chip).join('')+(more>0?'<span class="more">+'+more+'</span>':'')+'</span></button>';
  }
  h+='</div>';
  $('#view').innerHTML=h;
}
function renderList(){
  var list=scopeItems().sort(cmp);
  if(!list.length){
    $('#view').innerHTML='<div class="panel"><div class="empty">Belum ada kegiatan '+(S.scope==='all'?'yang cocok dengan filter.':'di '+MONTHS[S.m]+' '+S.y+'.')+' Gunakan tombol Tambah kegiatan untuk mulai.</div></div>';
    return;
  }
  var h='<div class="tablewrap"><table><thead><tr><th>Tanggal</th><th>Kegiatan</th><th>Kategori</th><th>Prioritas</th><th>Status</th><th>PIC</th><th class="nm">Revisi</th></tr></thead><tbody>';
  list.forEach(function(it){
    var c=chOf(it.channel),s=stOf(it.status),d=parseISO(it.date),o=openRev(it),tot=(it.revisions||[]).length;
    h+='<tr class="trow" tabindex="0" data-id="'+esc(it.id)+'">'+
      '<td class="dt">'+DAYS_S[(d.getDay()+6)%7]+', '+d.getDate()+' '+MON_S[d.getMonth()]+(S.scope==='all'?' '+d.getFullYear():'')+'</td>'+
      '<td>'+esc(it.title)+(it.example?'<span class="exmark">contoh</span>':'')+(it.campaign?'<span class="t-sub">'+esc(it.campaign)+'</span>':'')+'</td>'+
      '<td><span class="chn" style="--c:'+c.c+'"><i></i>'+esc(c.name)+'</span></td>'+
      '<td>'+esc(it.format)+'</td>'+
      '<td><span class="pill" style="--sc:'+s.c+'"><i></i>'+esc(s.name)+'</span></td>'+
      '<td>'+esc(it.pic||'-')+'</td>'+
      '<td class="nm">'+(tot?(o?'<span class="revbadge">'+o+' terbuka</span>':'<span class="t-sub">'+tot+' selesai</span>'):'-')+'</td></tr>';
  });
  h+='</tbody></table></div>';
  $('#view').innerHTML=h;
}
function renderDay(){
  var d=parseISO(S.sel);
  var list=filtered().filter(function(i){return i.date===S.sel}).sort(cmp);
  var key=keyLabel(d.getFullYear(),d.getMonth(),d.getDate());
  var h='<h2>'+dayName(S.sel)+', '+d.getDate()+' '+MON_S[d.getMonth()]+' <span>'+d.getFullYear()+'</span></h2>';
  if(key) h+='<span class="keytag">'+esc(key)+'</span>';
  if(list.length){
    h+='<div class="rows">'+list.map(function(it){
      var c=chOf(it.channel),s=stOf(it.status);
      var o=openRev(it);var meta=[c.name,'Prioritas '+it.format].concat(it.pic?[it.pic]:[]).concat(o?[o+' revisi terbuka']:[]).join(' · ');
      return '<button type="button" class="row" style="--c:'+c.c+'" data-id="'+esc(it.id)+'"><i class="dot"></i><span class="r-main"><span class="r-title">'+esc(it.title)+'</span><span class="r-meta">'+esc(meta)+'</span></span><span class="pill" style="--sc:'+s.c+'"><i></i>'+esc(s.name)+'</span></button>';
    }).join('')+'</div>';
  } else {
    h+='<div class="empty">Belum ada kegiatan pada tanggal ini.</div>';
  }
  h+='<button type="button" class="btn primary" data-add="1">Tambah kegiatan di tanggal ini</button>';
  $('#dayPanel').innerHTML=h;
}

/* ---------- navigation ---------- */
function go(delta){
  var d=new Date(S.y,S.m+delta,1);
  S.y=d.getFullYear();S.m=d.getMonth();
  var sd=parseISO(S.sel);
  if(sd.getFullYear()!==S.y||sd.getMonth()!==S.m){
    S.sel=(today.getFullYear()===S.y&&today.getMonth()===S.m)?TODAY:toISO(new Date(S.y,S.m,1));
  }
  render();
}
function selectDate(iso){
  var d=parseISO(iso);
  S.sel=iso;S.y=d.getFullYear();S.m=d.getMonth();
  render();
  if(window.matchMedia('(max-width:980px)').matches){
    var p=$('#dayPanel');if(p&&p.scrollIntoView)p.scrollIntoView({block:'nearest'});
  }
}

/* ---------- form ---------- */
function fillSelect(sel,opts,valKey,labKey){
  sel.innerHTML=opts.map(function(o){
    var v=typeof o==='string'?o:o[valKey],l=typeof o==='string'?o:o[labKey];
    return '<option value="'+esc(v)+'">'+esc(l)+'</option>';
  }).join('');
}
function refreshDatalists(){
  function uniq(key){var m={};S.items.forEach(function(i){if(i[key])m[i[key]]=1});return Object.keys(m).sort()}
  $('#dl-campaign').innerHTML=uniq('campaign').map(function(v){return '<option value="'+esc(v)+'"></option>'}).join('');
  $('#dl-pic').innerHTML=uniq('pic').map(function(v){return '<option value="'+esc(v)+'"></option>'}).join('');
}
function openForm(id,dateISO,preset){
  lastFocus=document.activeElement;
  editingId=id||null;
  var it=id?S.items.filter(function(i){return i.id===id})[0]:null;
  var base=it||preset||{date:dateISO||S.sel,title:'',channel:'rapat',format:'Sedang',status:'rencana',campaign:'',pic:'',notes:'',revisions:[]};
  refreshDatalists();
  $('#formTitle').textContent=it?'Ubah kegiatan':'Tambah kegiatan';
  var le=$('#lastEdit');
  if(it&&it.ver&&gasOn()){le.textContent='Terakhir diubah'+(it.by?' oleh '+it.by:'')+' · '+whenText(it.ver);le.hidden=false}else le.hidden=true;
  $('#f-title').value=base.title||'';
  $('#f-date').value=base.date||S.sel;
  $('#f-channel').value=base.channel;
  $('#f-format').value=base.format;
  $('#f-status').value=base.status;
  $('#f-campaign').value=base.campaign||'';
  $('#f-pic').value=base.pic||'';
  revDraft=(base.revisions||[]).map(function(r){return {id:r.id,date:r.date,text:r.text,done:!!r.done}});
  $('#f-revtext').value='';renderRevs();
  $('#f-notes').value=base.notes||'';
  $('#e-title').hidden=true;$('#e-date').hidden=true;
  $('#dupBtn').hidden=!it;
  resetDelete();
  $('#delBtn').hidden=!it;
  $('#overlay').hidden=false;
  setTimeout(function(){$('#f-title').focus()},0);
}
function closeForm(){
  $('#overlay').hidden=true;editingId=null;resetDelete();
  if(lastFocus&&lastFocus.focus&&document.contains(lastFocus)) lastFocus.focus();
}
function resetDelete(){
  clearTimeout(delTimer);
  var b=$('#delBtn');b.textContent='Hapus';b.classList.remove('danger');b.dataset.armed='';
}
function saveForm(e){
  e.preventDefault();
  var title=$('#f-title').value.trim(), date=$('#f-date').value;
  $('#e-title').hidden=!!title;$('#e-date').hidden=!!date;
  if(!title){$('#f-title').focus();return}
  if(!date){$('#f-date').focus();return}
  var data={
    date:date,title:title,channel:$('#f-channel').value,format:$('#f-format').value,status:$('#f-status').value,
    campaign:$('#f-campaign').value.trim(),pic:$('#f-pic').value.trim(),notes:$('#f-notes').value.trim()
  };
  addRevision();
  data.revisions=revDraft.map(function(r){return {id:r.id,date:r.date,text:r.text,done:r.done}});
  var saved=null;
  if(editingId){
    var it=S.items.filter(function(i){return i.id===editingId})[0];
    if(it){Object.assign(it,data);it.example=false;saved=it}
  }
  if(!saved){
    saved=Object.assign({id:uid(),example:false},data);
    S.items.push(saved);
  }
  var d=parseISO(date);S.sel=date;S.y=d.getFullYear();S.m=d.getMonth();
  closeForm();changed([{op:'upsert',item:saved}]);render();toast('Kegiatan disimpan.');
}
function renderRevs(){
  var ul=$('#revList');
  var open=revDraft.filter(function(r){return !r.done}).length;
  $('#revCount').textContent=revDraft.length?'('+open+' terbuka, '+(revDraft.length-open)+' selesai)':'';
  if(!revDraft.length){ul.innerHTML='<li class="revempty">Belum ada catatan revisi.</li>';return}
  ul.innerHTML=revDraft.map(function(r,k){
    var d=parseISO(r.date);
    return '<li class="rev'+(r.done?' done':'')+'" data-rid="'+esc(r.id)+'">'+
      '<input type="checkbox" class="revchk" aria-label="Tandai revisi '+(k+1)+' selesai"'+(r.done?' checked':'')+'>'+
      '<span class="revbody"><span class="revtext">'+esc(r.text)+'</span><span class="revmeta">Revisi '+(k+1)+' &middot; dicatat '+d.getDate()+' '+MON_S[d.getMonth()]+' '+d.getFullYear()+'</span></span>'+
      '<button type="button" class="btn revdel" aria-label="Hapus revisi '+(k+1)+'">Hapus</button></li>';
  }).join('');
}
function addRevision(){
  var inp=$('#f-revtext'),v=inp.value.trim();
  if(!v)return false;
  revDraft.push({id:uid(),date:TODAY,text:v,done:false});
  inp.value='';renderRevs();return true;
}
function deleteItem(){
  var delId=editingId;
  var removed=S.items.filter(function(i){return i.id===delId})[0];
  if(!removed)return;
  S.items=S.items.filter(function(i){return i.id!==delId});
  closeForm();changed([{op:'delete',id:delId,ver:removed.ver}]);render();
  toast('Kegiatan "'+(removed.title.length>30?removed.title.slice(0,30)+'…':removed.title)+'" dihapus.',{label:'Urungkan',fn:function(){
    if(S.items.some(function(i){return i.id===removed.id}))return;
    S.items.push(removed);
    var d=parseISO(removed.date);S.sel=removed.date;S.y=d.getFullYear();S.m=d.getMonth();
    changed(removed.example?[]:[{op:'upsert',item:removed,force:true}]);render();toast('Kegiatan dikembalikan.');
  }});
}
function duplicateItem(){
  var it=S.items.filter(function(i){return i.id===editingId})[0];
  if(!it)return;
  var copy=Object.assign({},it,{title:it.title+' (salinan)',revisions:[],ver:0,by:''});
  closeForm();openForm(null,null,copy);
}

/* ---------- export ---------- */
function serial(iso){var d=parseISO(iso);return Math.round((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(1899,11,30))/86400000)}
function buildWB(list,label){
  var X=window.XLSX;
  var rows=list.slice().sort(cmp), n=rows.length;
  var openAll=rows.reduce(function(s,i){return s+openRev(i)},0);
  var aoa=[['Tanggal','Hari','Kegiatan','Kategori','Prioritas','Proyek','Status','PIC','Revisi terbuka','Catatan','Catatan revisi']];
  rows.forEach(function(it){
    aoa.push([serial(it.date),dayName(it.date),it.title,chOf(it.channel).name,it.format||'',it.campaign||'',stOf(it.status).name,it.pic||'',openRev(it),it.notes||'',revText(it)]);
  });
  aoa.push(['Total','','','','','','','',openAll,'','']);
  var ws=X.utils.aoa_to_sheet(aoa);
  for(var r=2;r<=n+1;r++){ws['A'+r].z='dd/mm/yyyy'}
  ws['I'+(n+2)]={t:'n',v:openAll,f:'SUM(I2:I'+(n+1)+')'};
  ws['!cols']=[{wch:12},{wch:9},{wch:36},{wch:16},{wch:10},{wch:22},{wch:12},{wch:14},{wch:14},{wch:36},{wch:60}];
  ws['!autofilter']={ref:'A1:K'+(n+1)};

  var ra=[['Tanggal kegiatan','Kegiatan','Revisi ke','Tanggal dicatat','Catatan revisi','Status revisi']];
  rows.forEach(function(it){(it.revisions||[]).forEach(function(rv,k){ra.push([serial(it.date),it.title,k+1,serial(rv.date),rv.text,rv.done?'Selesai':'Terbuka'])})});
  var ws3=X.utils.aoa_to_sheet(ra);
  for(var q=2;q<=ra.length;q++){ws3['A'+q].z='dd/mm/yyyy';ws3['D'+q].z='dd/mm/yyyy'}
  ws3['!cols']=[{wch:16},{wch:36},{wch:10},{wch:16},{wch:60},{wch:14}];
  ws3['!autofilter']={ref:'A1:F'+Math.max(ra.length,2)};

  var last=n+1;
  function rng(col){return "'Kalender Kerja'!$"+col+'$2:$'+col+'$'+last}
  var s=[['Ringkasan kalender kegiatan kerja'],[label],[],['Kategori','Jumlah kegiatan','Revisi terbuka']];
  var chStart=s.length+1;
  CH.forEach(function(c){
    var its=rows.filter(function(i){return i.channel===c.id});
    s.push([c.name,its.length,its.reduce(function(a,i){return a+openRev(i)},0)]);
  });
  var chEnd=s.length;
  s.push(['Total',n,openAll]);
  s.push([]);
  s.push(['Status','Jumlah kegiatan']);
  var stStart=s.length+1;
  ST.forEach(function(st){s.push([st.name,rows.filter(function(i){return i.status===st.id}).length])});
  var ws2=X.utils.aoa_to_sheet(s);
  CH.forEach(function(c,i){
    var r=chStart+i;
    ws2['B'+r]={t:'n',v:ws2['B'+r].v,f:'COUNTIF('+rng('D')+',A'+r+')'};
    ws2['C'+r]={t:'n',v:ws2['C'+r].v,f:'SUMIF('+rng('D')+',A'+r+','+rng('I')+')'};
  });
  var tr=chEnd+1;
  ws2['B'+tr]={t:'n',v:n,f:'SUM(B'+chStart+':B'+chEnd+')'};
  ws2['C'+tr]={t:'n',v:openAll,f:'SUM(C'+chStart+':C'+chEnd+')'};
  ST.forEach(function(st,i){
    var r=stStart+i;
    ws2['B'+r]={t:'n',v:ws2['B'+r].v,f:'COUNTIF('+rng('G')+',A'+r+')'};
  });
  ws2['!cols']=[{wch:28},{wch:18},{wch:16}];
  var wb=X.utils.book_new();
  X.utils.book_append_sheet(wb,ws,'Kalender Kerja');
  X.utils.book_append_sheet(wb,ws3,'Catatan Revisi');
  X.utils.book_append_sheet(wb,ws2,'Ringkasan');
  return wb;
}
function exportList(scope){return scope==='all'?S.items:S.items.filter(inMonth)}
function scopeLabel(scope){return scope==='all'?'Semua rencana':MONTHS[S.m]+' '+S.y}
function downloadBlob(blob,filename){
  var url=URL.createObjectURL(blob);
  var a=document.createElement('a');
  a.href=url;a.download=filename;a.rel='noopener';
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(function(){URL.revokeObjectURL(url)},4000);
}
/* ---------- aplikasi Android (Capacitor) ---------- */
function isNative(){return !!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform())}
function plug(n){return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins[n]}
// Di aplikasi Android, unduhan file tidak didukung WebView: simpan ke cache lalu buka menu Bagikan (Drive, WhatsApp, File, dll).
function nativeShareFile(name,b64){
  var FS=plug('Filesystem'),SH=plug('Share');
  if(!FS||!SH){toast('Plugin Filesystem/Share belum terpasang di aplikasi.');return}
  FS.writeFile({path:name,data:b64,directory:'CACHE'}).then(function(r){
    return SH.share({title:name,dialogTitle:'Simpan atau kirim file Excel',files:[r.uri]});
  }).then(function(){toast('File Excel siap dibagikan.')},function(e){
    var m=e&&e.message||'';if(/cancel/i.test(m))return;toast('Gagal membagikan file'+(m?': '+m:'.'));
  });
}
function nativeInit(){
  if(!isNative())return;
  document.documentElement.classList.add('native');
  var App=plug('App');
  if(App&&App.addListener){
    App.addListener('backButton',function(){
      if(!$('#conflictOverlay').hidden)return; // harus memilih dulu
      if(!$('#gasOverlay').hidden){closeGas();return}
      if(!$('#overlay').hidden){closeForm();return}
      if(!$('#exportMenu').hidden){closeMenu();return}
      if(chat.open){chatOpen(false);return}
      if($('#filters').classList.contains('open')){$('#filterToggle').click();return}
      if(App.minimizeApp)App.minimizeApp();else if(App.exitApp)App.exitApp();
    });
    App.addListener('resume',function(){pull();chatPoll().then(chatSchedule)});
  }
}
function doExport(scope){
  closeMenu();
  var list=exportList(scope);
  if(!list.length){toast('Tidak ada kegiatan untuk diexport.');return}
  if(!window.XLSX){toast('Library Excel belum termuat. Periksa koneksi internet atau folder vendor/.');return}
  try{
    var wb=buildWB(list,scopeLabel(scope));
    var name='kalender-kerja-'+(scope==='all'?'semua':S.y+'-'+pad(S.m+1))+'.xlsx';
    if(isNative()){nativeShareFile(name,window.XLSX.write(wb,{bookType:'xlsx',type:'base64'}));return}
    var data=window.XLSX.write(wb,{bookType:'xlsx',type:'array'});
    downloadBlob(new Blob([data],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),name);
    toast('File Excel diunduh.');
  }catch(e){
    toast('Export gagal'+(e&&e.message?': '+e.message:'.'));
  }
}
function copyTable(scope){
  closeMenu();
  var list=exportList(scope).slice().sort(cmp);
  if(!list.length){toast('Tidak ada kegiatan untuk disalin.');return}
  function cell(v){return String(v==null?'':v).replace(/[\t\r\n]+/g,' ')}
  var lines=[['Tanggal','Hari','Kegiatan','Kategori','Prioritas','Proyek','Status','PIC','Revisi terbuka','Catatan','Catatan revisi'].join('\t')];
  list.forEach(function(it){
    lines.push([it.date,dayName(it.date),it.title,chOf(it.channel).name,it.format,it.campaign,stOf(it.status).name,it.pic,openRev(it),it.notes,revText(it)].map(cell).join('\t'));
  });
  var text=lines.join('\n');
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(function(){toast('Tabel disalin. Tempel di Excel atau Google Sheets.')},function(){toast('Browser menolak penyalinan.')});
  } else toast('Browser menolak penyalinan.');
}
function openMenu(){
  var m=$('#exportMenu');
  var cm=exportList('month').length, ca=exportList('all').length;
  var dlOk=!!window.XLSX;
  m.innerHTML=
    '<button type="button" data-x="xlsx-month"'+(dlOk?'':' disabled')+'>Unduh Excel (.xlsx)<span class="m-sub">'+esc(MONTHS[S.m]+' '+S.y)+' &middot; '+cm+' kegiatan</span></button>'+
    '<button type="button" data-x="xlsx-all"'+(dlOk?'':' disabled')+'>Unduh Excel (.xlsx)<span class="m-sub">Semua rencana &middot; '+ca+' kegiatan</span></button>'+
    '<button type="button" data-x="copy-month">Salin sebagai tabel<span class="m-sub">Tempel langsung ke Excel atau Google Sheets</span></button>'+
    '<div class="m-hint">'+(dlOk?'Export mengabaikan filter dan pencarian. File berisi sheet Kalender Kerja, Catatan Revisi, dan Ringkasan.':'Library Excel belum termuat. Periksa koneksi internet atau folder vendor/.')+'</div>';
  m.hidden=false;$('#exportBtn').setAttribute('aria-expanded','true');
}
function closeMenu(){$('#exportMenu').hidden=true;$('#exportBtn').setAttribute('aria-expanded','false')}

/* ---------- toast ---------- */
function toast(msg,action){
  var t=$('#toast');t.innerHTML='';
  var sp=document.createElement('span');sp.textContent=msg;t.appendChild(sp);
  if(action){
    var b=document.createElement('button');b.type='button';b.className='toastbtn';b.textContent=action.label;
    b.addEventListener('click',function(){clearTimeout(toastTimer);t.hidden=true;action.fn()});
    t.appendChild(b);
  }
  t.hidden=false;
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){t.hidden=true},action?7000:3200);
}

/* ---------- wiring ---------- */
function buildStatic(){
  $('#chFilters').innerHTML=CH.map(function(c){return '<button type="button" class="fch" data-ch="'+c.id+'" style="--c:'+c.c+'" aria-pressed="false"><i></i>'+esc(c.name)+'</button>'}).join('');
  $('#stFilter').innerHTML='<option value="">Semua status</option>'+ST.map(function(s){return '<option value="'+s.id+'">'+esc(s.name)+'</option>'}).join('');
  fillSelect($('#f-channel'),CH,'id','name');
  fillSelect($('#f-format'),FORMATS);
  fillSelect($('#f-status'),ST,'id','name');

  $('#prevBtn').addEventListener('click',function(){go(-1)});
  $('#nextBtn').addEventListener('click',function(){go(1)});
  $('#todayBtn').addEventListener('click',function(){S.y=today.getFullYear();S.m=today.getMonth();S.sel=TODAY;render()});
  $('#vMonth').addEventListener('click',function(){S.view='month';render()});
  $('#vList').addEventListener('click',function(){S.view='list';render()});
  $('#sMonth').addEventListener('click',function(){S.scope='month';render()});
  $('#sAll').addEventListener('click',function(){S.scope='all';render()});
  $('#addBtn').addEventListener('click',function(){openForm(null,S.sel)});
  $('#exportBtn').addEventListener('click',function(e){e.stopPropagation();if($('#exportMenu').hidden)openMenu();else closeMenu()});
  $('#exportMenu').addEventListener('click',function(e){
    var b=e.target.closest('button[data-x]');if(!b||b.disabled)return;
    var x=b.dataset.x;
    if(x==='xlsx-month')doExport('month');else if(x==='xlsx-all')doExport('all');else copyTable('month');
  });
  $('#clearExamples').addEventListener('click',function(){
    var ex=S.items.filter(function(i){return i.example});
    S.items=S.items.filter(function(i){return !i.example});
    changed(ex.map(function(i){return {op:'delete',id:i.id}}));render();toast('Data contoh dihapus.');
  });
  $('#gasBtn').addEventListener('click',openGas);
  $('#cfMine').addEventListener('click',function(){resolveConflict(true)});
  $('#cfTheirs').addEventListener('click',function(){resolveConflict(false)});
  $('#filterToggle').addEventListener('click',function(){
    var open=!$('#filters').classList.contains('open');
    $('#filters').classList.toggle('open',open);this.setAttribute('aria-expanded',open);
  });
  $('#saveState').addEventListener('click',function(){
    if(gasOn()&&gas.state==='error'){gas.queue.length?flush():pull(true);return}
    openGas();
  });
  $('#gasForm').addEventListener('submit',gasConnect);
  $('#gasTest').addEventListener('click',gasTest);
  $('#gasClose').addEventListener('click',closeGas);
  $('#gasPush').addEventListener('click',gasPushAll);
  $('#gasPull').addEventListener('click',function(){
    gasMsg('Memuat…');
    pull(true).then(function(){gas.state==='error'?gasMsg(gas.err,'err'):gasMsg('Dimuat ulang. '+S.items.length+' kegiatan.','ok')});
  });
  $('#gasOff').addEventListener('click',gasDisconnect);
  $('#gasOverlay').addEventListener('mousedown',function(e){if(e.target===$('#gasOverlay'))closeGas()});
  window.addEventListener('online',function(){flush()});
  document.addEventListener('visibilitychange',function(){
    if(document.visibilityState==='visible'&&Date.now()-gas.lastPull>30000)pull();
  });
  setInterval(function(){if(document.visibilityState==='visible'&&$('#gasOverlay').hidden)pull()},60000);
  $('#chFilters').addEventListener('click',function(e){
    var b=e.target.closest('.fch');if(!b)return;
    var id=b.dataset.ch;if(S.fCh.has(id))S.fCh.delete(id);else S.fCh.add(id);render();
  });
  $('#stFilter').addEventListener('change',function(e){S.fSt=e.target.value;render()});
  $('#qFilter').addEventListener('input',function(e){S.q=e.target.value.trim();render()});
  $('#resetFilter').addEventListener('click',function(){S.fCh.clear();S.fSt='';S.fRev=false;S.q='';$('#stFilter').value='';$('#qFilter').value='';render()});
  $('#view').addEventListener('click',function(e){
    var c=e.target.closest('.cell');
    if(c){selectDate(c.dataset.date);return}
    var r=e.target.closest('.trow');
    if(r)openForm(r.dataset.id);
  });
  $('#view').addEventListener('keydown',function(e){
    if(e.key!=='Enter'&&e.key!==' ')return;
    var r=e.target.closest&&e.target.closest('.trow');
    if(r){e.preventDefault();openForm(r.dataset.id)}
  });
  $('#dayPanel').addEventListener('click',function(e){
    var r=e.target.closest('.row');
    if(r){openForm(r.dataset.id);return}
    if(e.target.closest('[data-add]'))openForm(null,S.sel);
  });
  $('#revFilter').addEventListener('click',function(){S.fRev=!S.fRev;render()});
  $('#revAddBtn').addEventListener('click',function(){addRevision();$('#f-revtext').focus()});
  $('#f-revtext').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();addRevision()}});
  $('#revList').addEventListener('change',function(e){
    var li=e.target.closest('li[data-rid]');if(!li||!e.target.classList.contains('revchk'))return;
    revDraft.forEach(function(r){if(r.id===li.dataset.rid)r.done=e.target.checked});renderRevs();
  });
  $('#revList').addEventListener('click',function(e){
    var li=e.target.closest('li[data-rid]');if(!li||!e.target.classList.contains('revdel'))return;
    revDraft=revDraft.filter(function(r){return r.id!==li.dataset.rid});renderRevs();
  });
  $('#form').addEventListener('submit',saveForm);
  $('#cancelBtn').addEventListener('click',closeForm);
  $('#delBtn').addEventListener('click',deleteItem);
  $('#dupBtn').addEventListener('click',duplicateItem);
  $('#overlay').addEventListener('mousedown',function(e){if(e.target===$('#overlay'))closeForm()});
  document.addEventListener('click',function(e){if(!e.target.closest('.menuwrap'))closeMenu()});
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){
      if(!$('#gasOverlay').hidden)closeGas();else if(!$('#overlay').hidden)closeForm();else if(chat.open)chatOpen(false);else closeMenu();
    }
  });
}

/* ---------- konflik edit bersamaan ---------- */
function myName(){try{return (typeof chat!=='undefined'&&chat.name)||localStorage.getItem('kalender-kerja-nama')||''}catch(e){return ''}}
function whenText(ts){
  var d=new Date(ts),k=toISO(d);
  var day=k===TODAY?'hari ini':(k===toISO(addDays(new Date(),-1))?'kemarin':d.getDate()+' '+MON_S[d.getMonth()]+' '+d.getFullYear());
  return day+' '+pad(d.getHours())+'.'+pad(d.getMinutes());
}
function applyVers(vers){
  var me=myName();
  Object.keys(vers).forEach(function(id){
    var v=vers[id];
    S.items.forEach(function(i){if(i.id===id){i.ver=v;i.by=me}});
    gas.queue.forEach(function(o){ // op berikutnya untuk kegiatan yang sama memakai versi terbaru
      if(o.op==='upsert'&&o.item&&o.item.id===id)o.item.ver=v;
      if(o.op==='delete'&&o.id===id)o.ver=v;
    });
  });
  if(Object.keys(vers).length)lsWrite();
}
var conflicts=[];
function addConflict(c,op){
  if(conflicts.some(function(x){return x.c.id===c.id}))return;
  conflicts.push({c:c,op:op});
  if($('#conflictOverlay').hidden)showConflict();
}
var FIELD_LABELS=[['title','Nama'],['date','Tanggal'],['channel','Kategori'],['format','Prioritas'],['status','Status'],['campaign','Proyek'],['pic','PIC'],['notes','Catatan']];
function fieldVal(it,k){
  if(k==='channel')return chOf(it.channel).name;
  if(k==='status')return stOf(it.status).name;
  if(k==='date')return it.date?longDate(it.date):'';
  return it[k]||'';
}
function diffRows(mine,theirs){
  var rows=FIELD_LABELS.filter(function(f){return String(fieldVal(mine,f[0]))!==String(fieldVal(theirs,f[0]))}).map(function(f){
    return '<tr><th>'+esc(f[1])+'</th><td>'+esc(fieldVal(mine,f[0])||'-')+'</td><td>'+esc(fieldVal(theirs,f[0])||'-')+'</td></tr>';
  });
  var rm=revText(mine),rt=revText(theirs);
  if(rm!==rt)rows.push('<tr><th>Revisi</th><td>'+(mine.revisions||[]).length+' catatan ('+openRev(mine)+' terbuka)</td><td>'+(theirs.revisions||[]).length+' catatan ('+openRev(theirs)+' terbuka)</td></tr>');
  if(!rows.length)return '<p class="cf-same">Isinya sama persis, hanya waktu simpannya berbeda.</p>';
  return '<table class="cf-diff"><thead><tr><th></th><th>Versi Anda</th><th>Versi di Sheet</th></tr></thead><tbody>'+rows.join('')+'</tbody></table>';
}
function showConflict(){
  var x=conflicts[0];
  if(!x){$('#conflictOverlay').hidden=true;return}
  var c=x.c,op=x.op,srv=c.server?normalize(c.server):null;
  var mine=op.item?normalize(op.item):(S.items.filter(function(i){return i.id===c.id})[0]||srv);
  var name=esc((mine&&mine.title)||(srv&&srv.title)||'kegiatan');
  var who=srv?(srv.by?'<b>'+esc(srv.by)+'</b>':'orang lain')+' pada '+esc(whenText(srv.ver)):'';
  var h='',a='',b='';
  if(c.op==='upsert'&&srv){
    h='<p>Kegiatan <b>'+name+'</b> sudah diubah oleh '+who+', saat Anda sedang mengeditnya. Pilih versi yang dipakai:</p>'+diffRows(mine,srv);
    a='Pakai versi saya';b='Pakai versi di Sheet';
  } else if(c.op==='upsert'){
    h='<p>Kegiatan <b>'+name+'</b> sudah <b>dihapus</b> oleh orang lain, saat Anda sedang mengeditnya.</p>';
    a='Simpan lagi versi saya';b='Biarkan terhapus';
  } else {
    h='<p>Anda menghapus <b>'+name+'</b>, tetapi kegiatan ini baru saja diubah oleh '+who+'. Perubahan mereka ikut hilang jika tetap dihapus.</p>'+(srv?diffRows(mine||srv,srv):'');
    a='Tetap hapus';b='Batal hapus';
  }
  if(conflicts.length>1)h+='<p class="cf-more">'+(conflicts.length-1)+' konflik lain menunggu.</p>';
  $('#conflictBody').innerHTML=h;
  $('#cfMine').textContent=a;$('#cfTheirs').textContent=b;
  if($('#conflictOverlay').hidden){$('#conflictOverlay').hidden=false;setTimeout(function(){$('#cfTheirs').focus()},0)}
}
function resolveConflict(keepMine){
  var x=conflicts.shift();if(!x)return;
  var c=x.c,op=x.op,srv=c.server?normalize(c.server):null;
  if(c.op==='upsert'){
    var mine=normalize(op.item);
    S.items=S.items.filter(function(i){return i.id!==c.id});
    if(keepMine){S.items.push(mine);changed([{op:'upsert',item:mine,force:true}]);toast('Versi Anda disimpan.')}
    else{if(srv)S.items.push(srv);lsWrite();toast(srv?'Memakai versi di Sheet.':'Kegiatan dibiarkan terhapus.')}
  } else {
    if(keepMine){S.items=S.items.filter(function(i){return i.id!==c.id});changed([{op:'delete',id:c.id,force:true}]);toast('Kegiatan dihapus.')}
    else if(srv){S.items=S.items.filter(function(i){return i.id!==c.id});S.items.push(srv);lsWrite();toast('Hapus dibatalkan, memakai versi terbaru.')}
  }
  render();
  if(conflicts.length)showConflict();else $('#conflictOverlay').hidden=true;
}

/* ---------- chat tim ---------- */
var NAME_KEY='kalender-kerja-nama', SEEN_KEY='kalender-kerja-chat-seen';
var chat={open:false,msgs:[],ids:{},after:0,name:'',seen:0,timer:null,busy:false,loaded:false,err:'',baseTitle:document.title};
function chatGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function chatSet(k,v){try{localStorage.setItem(k,v)}catch(e){}}
function hhmm(ts){var d=new Date(ts);return pad(d.getHours())+'.'+pad(d.getMinutes())}
function dayKey(ts){var d=new Date(ts);return toISO(d)}
function dayLabel(ts){
  var k=dayKey(ts);if(k===toISO(new Date()))return 'Hari ini';
  if(k===toISO(addDays(new Date(),-1)))return 'Kemarin';
  return longDate(k);
}
function chatRender(){
  var body=$('#chatBody');
  if(!gasOn()){body.innerHTML='<div class="chatempty">Chat memakai Google Sheets. Hubungkan dulu lewat tombol <b>Google Sheets</b>.</div>';return}
  if(!chat.loaded){body.innerHTML='<div class="chatempty">Memuat pesan…</div>';return}
  if(!chat.msgs.length){body.innerHTML='<div class="chatempty">Belum ada pesan. Sapa tim Anda!</div>';return}
  var atBottom=body.scrollHeight-body.scrollTop-body.clientHeight<60;
  var h='',prevDay='',prevName='',prevTs=0;
  chat.msgs.forEach(function(m){
    var dk=dayKey(m.ts);
    if(dk!==prevDay){h+='<div class="chatday">'+esc(dayLabel(m.ts))+'</div>';prevName='';}
    var me=m.name===chat.name;
    var cont=m.name===prevName&&m.ts-prevTs<5*60000;
    var tm=m.state==='pending'?'mengirim…':m.state==='failed'?'gagal terkirim'+(m.err?': '+esc(m.err):'')+' · <button type="button" data-retry="'+esc(m.id)+'">kirim ulang</button>':hhmm(m.ts);
    h+='<div class="msg'+(me?' me':'')+(cont?' cont':'')+(m.state?' '+m.state:'')+'">'+(me?'':'<span class="who">'+esc(m.name)+'</span>')+'<span class="bub">'+esc(m.text)+'</span><span class="tm">'+tm+'</span></div>';
    prevDay=dk;prevName=m.name;prevTs=m.ts;
  });
  body.innerHTML=h;
  if(atBottom||chat.forceBottom){body.scrollTop=body.scrollHeight;chat.forceBottom=false}
}
function chatHeader(){
  $('#chatMe').textContent=chat.name?'Sebagai '+chat.name+' · ganti nama':'';
  $('#chatMe').hidden=!chat.name;
  var live=$('#chatLive');
  if(!gasOn()){live.innerHTML='';return}
  live.className='chatlive'+(chat.err?' err':'');
  live.innerHTML='<i></i>'+(chat.err?'terputus':'langsung');
  live.title=chat.err||'Pesan baru dicek setiap 3 detik';
  var needName=!chat.name&&gasOn();
  $('#chatNameForm').hidden=!needName;
  $('#chatForm').hidden=needName||!gasOn();
}
function chatBadge(){
  var unread=chat.msgs.filter(function(m){return m.ts>chat.seen&&m.name!==chat.name&&!m.state}).length;
  if(chat.open&&document.visibilityState==='visible')unread=0;
  var b=$('#chatBadge');b.hidden=!unread;b.textContent=unread>99?'99+':unread;
  document.title=(unread?'('+unread+') ':'')+chat.baseTitle;
}
function chatMarkSeen(){
  var last=chat.msgs.filter(function(m){return !m.state}).slice(-1)[0];
  if(last&&last.ts>chat.seen){chat.seen=last.ts;chatSet(SEEN_KEY,String(chat.seen))}
  chatBadge();
}
function chatAdd(list){
  var added=0;
  list.forEach(function(m){
    if(chat.ids[m.id]){ // pesan sendiri yang tadinya pending
      chat.msgs.forEach(function(x){if(x.id===m.id){x.ts=m.ts;x.state=''}});
    } else {chat.ids[m.id]=1;chat.msgs.push({id:m.id,ts:m.ts,name:m.name,text:m.text,state:''});added++}
    if(m.ts>chat.after)chat.after=m.ts;
  });
  chat.msgs.sort(function(a,b){return (a.state==='pending'||a.state==='failed'?1:0)-(b.state==='pending'||b.state==='failed'?1:0)||a.ts-b.ts});
  if(chat.msgs.length>300){chat.msgs=chat.msgs.slice(-300)}
  return added;
}
function chatPoll(){
  if(!gasOn()||chat.busy)return Promise.resolve();
  chat.busy=true;
  return gasCall({action:'chatList',after:chat.after}).then(function(j){
    chat.busy=false;chat.err='';
    var first=!chat.loaded;chat.loaded=true;
    var added=chatAdd(j.messages||[]);
    if(first&&!chat.seen){chat.seen=chat.after;chatSet(SEEN_KEY,String(chat.seen))}
    if(added||first){if(first)chat.forceBottom=true;chatRender()}
    if(chat.open&&document.visibilityState==='visible')chatMarkSeen();else chatBadge();
    chatHeader();
  },function(e){chat.busy=false;chat.err=e.message;chatHeader();if(!chat.loaded){chat.loaded=true;chatRender()}});
}
function chatSchedule(){
  clearTimeout(chat.timer);
  if(!gasOn())return;
  var visible=document.visibilityState==='visible';
  var ms=!visible?60000:chat.open?3000:20000;
  if(chat.err)ms=Math.max(ms,10000);
  chat.timer=setTimeout(function(){chatPoll().then(chatSchedule)},ms);
}
function chatSendMsg(m){
  m.state='pending';m.err='';chatRender();
  gasCall({action:'chatSend',id:m.id,name:m.name,text:m.text}).then(function(j){
    chatAdd([j.message]);chatRender();chatMarkSeen();
  },function(e){m.state='failed';m.err=e.message;chatRender();toast('Pesan gagal terkirim: '+e.message)});
}
function chatSubmit(e){
  e.preventDefault();
  var inp=$('#chatInput'),text=inp.value.trim();
  if(!text||!chat.name)return;
  var m={id:uid(),ts:Date.now(),name:chat.name,text:text,state:'pending'};
  chat.ids[m.id]=1;chat.msgs.push(m);
  inp.value='';chatAutosize();chat.forceBottom=true;
  chatSendMsg(m);
}
function chatAutosize(){var t=$('#chatInput');t.style.height='auto';t.style.height=Math.min(t.scrollHeight+2,120)+'px'}
function chatOpen(v){
  chat.open=v;
  $('#chatPanel').hidden=!v;$('#chatFab').setAttribute('aria-expanded',v);
  document.body.classList.toggle('chatopen',v);
  if(v){
    chatHeader();chat.forceBottom=true;chatRender();chatMarkSeen();
    setTimeout(function(){var f=chat.name?$('#chatInput'):$('#chatNameInput');if(f&&!f.closest('[hidden]'))f.focus()},0);
    chatPoll().then(chatSchedule);
  } else {$('#chatFab').focus();chatSchedule()}
}
function chatInit(){
  chat.name=chatGet(NAME_KEY)||'';chat.seen=Number(chatGet(SEEN_KEY)||0);
  $('#chatFab').addEventListener('click',function(){chatOpen(true)});
  $('#chatClose').addEventListener('click',function(){chatOpen(false)});
  $('#chatForm').addEventListener('submit',chatSubmit);
  $('#chatInput').addEventListener('input',chatAutosize);
  $('#chatInput').addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();$('#chatForm').requestSubmit()}});
  $('#chatNameForm').addEventListener('submit',function(e){
    e.preventDefault();var v=$('#chatNameInput').value.trim().slice(0,40);if(!v){$('#chatNameInput').focus();return}
    chat.name=v;chatSet(NAME_KEY,v);chatHeader();chatRender();setTimeout(function(){$('#chatInput').focus()},0);
  });
  $('#chatMe').addEventListener('click',function(){
    $('#chatNameInput').value=chat.name;chat.name='';chatHeader();$('#chatNameInput').focus();
  });
  $('#chatBody').addEventListener('click',function(e){
    var b=e.target.closest('[data-retry]');if(!b)return;
    chat.msgs.forEach(function(m){if(m.id===b.dataset.retry)chatSendMsg(m)});
  });
  document.addEventListener('visibilitychange',function(){
    if(document.visibilityState==='visible'){if(chat.open)chatMarkSeen();chatPoll().then(chatSchedule)}else chatSchedule();
  });
  chatHeader();
  if(gasOn())chatPoll().then(chatSchedule);
}

function init(){
  buildStatic();
  gasLoadCfg();
  var l=lsRead();
  if(l&&Array.isArray(l.items)){S.items=l.items.map(normalize)}
  else{S.items=gasOn()?[]:seeds()}
  storeMode=lsAvailable()?'local':'memory';
  render();
  if(gasOn())pull(true);
  chatInit();
  nativeInit();
}
init();
})();

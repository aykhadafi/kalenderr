# Kalender Kegiatan Kerja

Aplikasi web untuk mengatur kegiatan kerja: kalender bulanan, tampilan daftar, filter, catatan revisi, dan export ke Excel (.xlsx).

Project statis tanpa build. Data bisa disimpan ke **Google Sheets lewat Google Apps Script** (lihat bagian "Hubungkan ke Google Sheets"), atau hanya di browser jika tidak dihubungkan.

## Menjalankan

Cara paling mudah: buka `index.html` di browser.

Atau lewat server lokal:

```bash
npx serve .
# atau
python3 -m http.server 8080
```

Lalu buka alamat yang ditampilkan (contoh `http://localhost:8080`).

## Aplikasi Android

Lihat **ANDROID.md** untuk membuat APK dengan Capacitor (lewat GitHub Actions tanpa install apa pun, atau lewat Android Studio).

## Struktur

```
kalender-kerja/
  index.html          halaman utama
  css/style.css       tampilan (terang dan gelap mengikuti sistem)
  js/app.js           logika kalender, penyimpanan, export
  apps-script/
    Code.gs           backend Google Apps Script (simpan data ke Google Sheet)
    appsscript.json   manifest (zona waktu Asia/Jakarta, akses web app)
  vendor/             tempat salinan lokal SheetJS (opsional, lihat di bawah)
  package.json
```

## Fitur

- Kalender bulanan (Senin sampai Minggu) dengan penanda hari nasional bertanggal tetap.
- Tambah, ubah, duplikat, dan hapus kegiatan: nama, tanggal, kategori, prioritas, status, proyek, PIC, catatan.
- **Catatan revisi** per kegiatan: tambah catatan kapan saja, centang jika sudah dikerjakan, atau hapus. Kegiatan yang masih punya revisi terbuka diberi lencana merah di kalender dan angka di tabel.
- Filter per kategori, status, "Ada revisi terbuka", dan pencarian teks (termasuk isi catatan revisi).
- Ringkasan jumlah kegiatan, jumlah revisi terbuka, dan sebaran status.
- Export Excel untuk bulan yang tampil atau semua kegiatan. File berisi sheet **Kalender Kerja**, **Catatan Revisi** (satu baris per catatan), dan **Ringkasan** (rumus COUNTIF dan SUMIF).
- Tombol "Salin sebagai tabel" untuk menempel ke Excel atau Google Sheets.

## Hubungkan ke Google Sheets

1. Buat Google Sheet baru (misalnya "Kalender Kerja").
2. Di Sheet itu buka **Ekstensi → Apps Script**.
3. Hapus isi `Code.gs` bawaan, lalu tempel seluruh isi `apps-script/Code.gs`. Simpan.
4. (Opsional) Isi `var TOKEN = '...'` dengan kata sandi bebas agar tidak sembarang orang bisa mengubah data.
5. Pilih fungsi **setup** di toolbar, klik **Run**, lalu izinkan akses (Review permissions → pilih akun → Advanced → Go to project → Allow). Sheet **Kegiatan** dan **Catatan Revisi** akan dibuat.
6. Klik **Deploy → New deployment** → ikon roda gigi → **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone** (Siapa saja)
   Klik **Deploy**, lalu salin **Web app URL** (berakhiran `/exec`).
7. Buka `index.html` dengan editor teks, cari bagian `window.KK_CONFIG` di bawah, lalu isi **salah satu**:
   ```js
   window.KK_CONFIG = {
     scriptUrl: 'https://script.google.com/macros/s/AKfycb.../exec',
     deploymentId: '',
     token: ''
   };
   ```
   atau cukup `deploymentId: 'AKfycb...'` (Deployment ID dari Deploy → Manage deployments).
   Simpan file, lalu buka/refresh web. Semua orang yang membuka web ini langsung terhubung ke Sheet yang sama.

Alternatif tanpa mengedit HTML: biarkan `KK_CONFIG` kosong, lalu tempel URL lewat tombol **Google Sheets** di web (tersimpan per browser).

Catatan:
- Setiap tambah, ubah, hapus kegiatan langsung dikirim ke Sheet. Jika offline atau gagal, perubahan disimpan dalam antrean dan dikirim ulang otomatis (atau klik teks status di toolbar).
- Web memuat ulang data dari Sheet saat dibuka, saat tab kembali aktif, dan setiap 60 detik, jadi perubahan dari orang lain ikut tampil.
- Sheet **Kegiatan** boleh diedit langsung. Kategori dan Status ditulis dengan nama (contoh "Rapat", "Selesai"), tanggal dalam format tanggal. Baris baru tanpa ID akan diberi ID otomatis. Kolom **Data revisi (JSON)** sebaiknya tidak diubah manual.
- Sheet **Catatan Revisi** dibuat ulang otomatis setiap ada perubahan, gunakan hanya untuk dibaca.
- Jika `Code.gs` diubah, buat versi baru: **Deploy → Manage deployments → Edit (pensil) → Version: New version → Deploy**. URL tetap sama.
- Dengan akses "Anyone", siapa pun yang tahu URL bisa membaca dan mengubah data. Pakai `TOKEN` jika ini penting.

## Edit bersamaan (konflik)

Setiap kegiatan di Sheet punya kolom **Versi** dan **Diubah oleh**. Saat menyimpan, web mengirim versi yang dilihat ketika mulai mengedit. Jika ternyata kegiatan itu sudah diubah atau dihapus orang lain, perubahan tidak langsung menimpa. Muncul dialog **Diubah orang lain** berisi perbandingan "Versi Anda" dan "Versi di Sheet", lalu pengguna memilih versi yang dipakai.

- Form kegiatan menampilkan "Terakhir diubah oleh … · jam".
- Nama pengubah diambil dari nama yang diisi di Chat tim.
- Edit langsung di Sheet juga dihitung sebagai perubahan (lewat fungsi `onEdit` di Code.gs).

## Chat tim

Tombol **Chat tim** di pojok kanan bawah membuka ruang obrolan untuk semua orang yang memakai web ini (butuh koneksi Google Sheets).

- Saat pertama kali membuka chat, isi nama. Nama tersimpan di browser dan bisa diganti lewat tautan "ganti nama".
- Pesan disimpan di sheet **Chat** (ID, Waktu, Nama, Pesan, ts).
- Pesan baru dicek setiap 3 detik saat panel terbuka, 20 detik saat tertutup (dengan lencana jumlah pesan belum dibaca), dan 60 detik saat tab tidak aktif. Apps Script tidak mendukung koneksi langsung (WebSocket), jadi pesan muncul dengan jeda sekitar 2 sampai 5 detik.
- Jika memperbarui dari versi sebelumnya: tempel `Code.gs` terbaru, simpan, lalu **Deploy → Manage deployments → Edit → Version: New version → Deploy**.
- Kuota Apps Script akun Gmail gratis cukup untuk tim kecil (sekitar 5 sampai 15 orang yang membuka chat bersamaan).

## Penyimpanan data

Jika belum dihubungkan ke Google Sheets, data disimpan di `localStorage` browser (kunci `kalender-kerja-v1`). Saat terhubung, `localStorage` dipakai sebagai cache agar halaman tampil cepat. Data tidak berpindah antar browser atau perangkat. Mengosongkan data situs akan menghapusnya, jadi export Excel berkala berguna sebagai cadangan.

## Library Excel (SheetJS)

`index.html` memuat SheetJS 0.18.5 dari cdnjs. Jika ingin bisa jalan offline:

```bash
npm install xlsx@0.18.5
cp node_modules/xlsx/dist/xlsx.full.min.js vendor/
```

Jika CDN gagal dimuat, halaman otomatis memakai `vendor/xlsx.full.min.js`.

## Mengubah isi

- Daftar channel, status, dan tipe konten ada di bagian atas `js/app.js` (`CH` (kategori), `ST` (status), `FORMATS` (prioritas)).
- Warna dan font ada di blok `:root` pada `css/style.css`.
- Tanggal penting ada di objek `FIXED` pada `js/app.js`.
